
# Piki Betting UI (Demo)

A minimal Vite + React + TypeScript + Tailwind demo of a **survey + prediction market** UI.
Shows the question **“Do you like Cornell Tech?”** and lets users bet on the exact number of **Yes** responses out of 10.
Pricing rule: **cost = $0.10 × x** for betting on x Yes.

## Local Dev

```bash
npm install
npm run dev
```

Then open the printed localhost URL.

## Build

```bash
npm run build
npm run preview
```

## Repo Setup

```bash
git init
git add .
git commit -m "init: piki betting ui demo"
# Create a repo on GitHub named piki-betting-ui, then:
git branch -M main
git remote add origin https://github.com/<your-username>/piki-betting-ui.git
git push -u origin main
```

## Notes

- UI palette: modern black/white/blue, Tailwind-based.
- Swap the pricing rule or wire to an AMM later.
- Add wallet/balance stubs or odds as needed.
